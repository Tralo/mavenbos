package cn.itcast.crm.utils;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.type.CustomCollectionType;

import cn.itcast.crm.domain.Customer;

/**
 * Hibernate 操作工具类
 * 
 * @author seawind
 * 
 */
public class HibernateUtils {
	private static Configuration configuration;
	private static SessionFactory sessionFactory;

	static {
		configuration = new Configuration().configure();
		sessionFactory = configuration.buildSessionFactory();
	}

	public static Session openSession() {
		return sessionFactory.openSession();
	}

	public static void main(String[] args) {
		Session session = openSession();
		Customer customer = new Customer();
		//开启事务  
		Transaction tx = session.beginTransaction();  
		  
		//创建临时对象并
		customer.setName("李四");
		customer.setTelephone("377732847");
		customer.setAddress("四川");
		session.save(customer);
		tx.commit();
		session.close();
	}
}
